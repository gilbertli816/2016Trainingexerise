#include<iostream>
using namespace std;
const double g = 9.8;
double highland(double,double);
int main (){
   double a = 100;  double b= -1;
   while(b<4) {b++;
   double distance = highland(a,b);
   cout << "high = " << distance <<endl;
   }
}
   double highland(double a, double b){
      return  a-0.5*g*b*b  ;
}

