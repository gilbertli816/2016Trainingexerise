#include<iostream>
using namespace std;
class freefall {
  public:
    freefall(double t, double h, double g){

     time = t;
     highland = h;
     grand = g;
}
  ~freefall(){}
  double high(){
      return  highland-0.5*grand*time*time;

}
   private :
      double  highland ,time, grand;
};



int main()
{
   double  time ,highland ,grand;
   highland = 100;
   grand    = 9.8;
   time =      -1;

   while (time < 4 ) {
   time++;
   freefall myfreefall(time,highland,grand);
   double  result = myfreefall.high();
   cout << "result:" << result << endl ;
}


}
