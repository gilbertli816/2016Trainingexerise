#include<iostream>
using namespace std;
class freefall {
  public:
    freefall(double t, double h, double g){
    time = t;
    highland = h;
    grand = g;
}
  ~freefall(){}
      double high(){
      return  highland-0.5*grand*time*time;
}
   private :
      double  highland ,time, grand;
};

int main()
{
   double  time ,highland ,grand;
   highland = 100;
   grand    = 9.8;
   cout << "请输入落体的时间：" ;
   cin >> time;

   freefall myfreefall(time,highland,grand);
   double  result = myfreefall.high() ;
   if (time < 5)
   cout << "result:" << result << endl ;
   else if (time >=5 )
   cout << "result:100" << endl;
   return 0;
}

